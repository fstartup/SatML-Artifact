# Research Hypotheses — Version 0.5

All hypotheses remain propositions requiring empirical validation.

**H1 — Production readiness:** task success alone is insufficient to establish production readiness.

**H2 — Autonomy/control:** required control strength increases with action impact and autonomy, moderated by reversibility, sensitivity, criticality, blast radius and recovery capability.

**H3 — Trajectory evaluation:** trajectory-level evaluation identifies consequential failures that final-outcome evaluation can miss.

**H4 — Multi-agent economics:** multi-agent systems create net benefit only when incremental outcome improvement exceeds coordination, operating, complexity and risk costs.

**H5 — Successful-task economics:** successful-task cost is more decision-useful for production economics than model/API cost alone.

**H6 — Action containment:** explicit action boundaries reduce the impact of agent failures compared with unrestricted tool access.

**H7 — Recovery adequacy:** the safety of autonomous production action depends materially on the effectiveness and boundedness of recovery mechanisms, not only forward-action success.

**H8 — Evidence reconstruction:** complete execution evidence improves the ability of independent reviewers to reconstruct and diagnose agent behavior compared with conventional application logs alone.

**H9 — Delegation non-escalation:** explicit per-agent authority and non-transitive delegation reduce privilege-escalation exposure in multi-agent systems.

**H10 — Correlated failure:** additional agents do not necessarily improve reliability when agents share correlated models, data, prompts, tools or memory.

**H11 — Evaluation integrity:** protecting the evaluation environment from agent manipulation reduces false assurance about agent capability and safety.
