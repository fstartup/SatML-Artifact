# Security Model

Trust boundaries TB1–TB7. Threats include prompt injection, goal hijacking, excessive agency, tool misuse, identity/privilege abuse, data exfiltration, malicious tools, tool poisoning, supply-chain vulnerabilities, and unexpected code execution.
