# Scenario E — Fault Injection Findings v0.1

## Status

Deterministic laboratory implementation. No model calls were made.

## Result expectation

All eight injected faults are designed to terminate outside unrestricted autonomous
execution, either by escalation, fail-closed control, bounded recovery handling or
execution-state reconciliation.

## Interpretation guardrail

Passing these tests demonstrates that the synthetic control harness implements the
specified failure semantics. It does not establish that an LLM will always propose
safe actions under equivalent faults, nor does it estimate production failure rates.

## Next decision gate

Only faults for which model behavior remains an unresolved research variable should
consume real-model calls. Deterministic containment should be treated as an
architecture property; model behavior should be measured separately.
