# v2.10 Stateful Fault Implementation Note

The deterministic F1-F8 suite is retained unchanged as the baseline. v2.10 adds an
explicit synthetic state machine for the subset of post-action faults that may justify
real-model calls: F3, F4, F5 and F8.

The state machine records execution status, verification status, recovery status,
reconciliation status, state version, retry count, action id and attempt id. This prevents
the real-model experiment from representing a fault only as a label; the injected fault
becomes an explicit post-action state.

For the first real-model wave, F3 and F8 are enabled. After the initial action, the fault
is injected and a second model turn receives the resulting state. Any follow-on proposal
is passed through a deliberately reconciliation-required gateway path and cannot execute
autonomously in the first-wave experiment.

This design tests the model's observable response to uncertainty while preserving the
execution boundary independently of model behavior.


## v2.10.1 state-transition refinement

The F3/F8 first-wave observations justify preserving two explicit post-action states rather
than collapsing them into a generic fault condition:

1. `EXECUTED_UNVERIFIED`: execution is recorded as successful at the gateway, but the
   desired post-condition is not verified;
2. `EXECUTION_UNKNOWN`: the gateway cannot establish whether execution occurred.

The state machine therefore treats reconciliation as a mandatory control transition before
any new consequential action. A model can recommend reconciliation, but cannot use the
existence of a retry budget or continued unhealthy state as authority to bypass reconciliation.

The first-wave real-model observations satisfied the protocol stopping condition. No new
model calls are required for F3/F8.
