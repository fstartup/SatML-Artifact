# SaTML 2027 HotCRP Draft Fields

## Title
Consequence-Boundary Control for Trustworthy Agentic AI Systems

## Category
Research Paper

## New Insights
N/A

## Short contribution summary
This paper develops and evaluates a consequence-boundary control model for trustworthy agentic AI systems. It separates probabilistic model capability from consequential authority through deterministic action-level authorization, evidence and state controls, recovery boundaries, and economic limits. The evaluation combines deterministic isolated-fault, compound-fault, and bounded-versus-bypass counterfactual testing with a limited cross-provider model pilot, while separately measuring model behavior, gateway enforcement, and consequence outcomes.

## Suggested topics
- Secure and safe machine learning in practice
- Verification of algorithms and systems
- Machine learning system security
- Trustworthy machine learning in cybersecurity applications
- Agentic AI / autonomous systems (select the closest available HotCRP topic)

## Abstract
Agentic AI systems connect probabilistic model behavior to tools, enterprise systems, other agents, and consequential actions. This paper studies whether consequential authority can remain bounded when agent proposals encounter adversarial inputs, incomplete evidence, state changes, tool ambiguity, recovery failure, and compound operational faults. We present a consequence-boundary control model that separates probabilistic capability from action authority through deterministic authorization, evidence, state, recovery, and economic controls. The primary empirical case is autonomous production operations, evaluated through eight isolated faults, three compound faults, and an 11-case bounded-versus-bypass counterfactual ablation checked against an independently implemented reference oracle. A limited cross-provider pilot using GPT-5-nano and Claude Haiku 4.5 examines selected stateful failures. The evaluation separately measures model behavior, gateway behavior, and consequential outcome. Across the tested synthetic conditions, the bounded implementation prevented the defined unauthorized or authority-expanding transitions, while the counterfactual bypass exposed the corresponding transitions. The evidence is implementation-level and exploratory, not statistical evidence of model safety or production readiness.
