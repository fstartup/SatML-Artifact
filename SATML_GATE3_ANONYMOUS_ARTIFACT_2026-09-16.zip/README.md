## v1.2 real-model connectivity

The real-model pilot supports OpenAI, Anthropic, Azure OpenAI and Microsoft Foundry project endpoints. Azure/Foundry uses the OpenAI-compatible `/openai/v1/` Responses API while preserving the synthetic Scenario A gateway and deterministic policy boundary.

# ANONYMOUS_RESEARCH — Engineering Production-Grade Agentic AI Systems

**Working manuscript v1.0 — 2026**

This repository contains a research/practitioner working manuscript proposing an integrated engineering model for production-grade agentic AI.

## Current status

Scenarios A–E have been used as adversarial architecture challenges. A cross-scenario synthesis now consolidates the candidate architecture, architectural invariants, action-level authorization, production autonomy controls, evidence continuity and recovery capability.

The architecture remains a **candidate engineering model**, not a universal safety theorem or production-readiness certification. The empirical protocol, deterministic fault program, compound-fault closure, and selected exploratory real-model observations are complete; broader empirical validation remains future work.

## Key files

- `00_MASTER_PAPER.md` — living manuscript
- `04_REFERENCE_ARCHITECTURE.md` — consolidated candidate architecture
- `05_ARCHITECTURE_CHALLENGE.md` — scenario challenge record
- `06_RESEARCH_HYPOTHESES.md` — testable hypotheses
- `07_EVALUATION_MODEL.md` — evaluation design
- `09_RELIABILITY_MODEL.md` — reliability and recovery model
- `10_ECONOMIC_MODEL.md` — agent and production economics
- `12_CROSS_SCENARIO_SYNTHESIS.md` — A–E architecture synthesis
- `13_EMPIRICAL_VALIDATION_PROTOCOL.md` — measurable validation and canonicalization protocol
- `14_EXPERIMENTAL_HARNESS.md` — executable research harness design
- `experiments/` — implementation scaffold for controlled experiments
- `references/REFERENCES.md` — research and standards references

## Central thesis

> Agentic production safety should be engineered as a controlled transition from probabilistic decision-making to consequential action, with authority granted at the action boundary and bounded by policy, evidence, impact, observability, recovery and economics.


### v1.0 status
Real-model adapter layer added for Scenario A. Provider-backed experiments are pilot infrastructure only; no production-safety claim is made from adapter execution.

## v1.0 pilot status

The Scenario A real-model layer is pilot-ready. A live provider run requires an explicitly configured provider API credential in the execution environment. No credential is embedded in this repository, and no live model result is claimed until such a run is executed.

The first live pilot should use the protocol in `experiments/cases/REAL_MODEL_PILOT_PROTOCOL.md`.

## Quick test execution

On Windows, from the extracted package, double-click `run_tests.cmd` or run it from Command Prompt. It executes the complete pytest suite and then the deterministic Scenario B TSECT suite. No API key is required for these tests.

## v2.6 update

Scenario B v2.6 refines the real-model evaluator before further model expansion. It adds a structured recommendation contract, separates untrusted-evidence presence from use and authority inference, distinguishes conflict mention from unsupported resolution, and introduces B7 as a direct decision-influence pressure test.

The package remains a research working copy. The architecture is a candidate engineering model; real-model observations are exploratory.

## Current empirical record

See `22_EMPIRICAL_OBSERVATION_REGISTER.md` for the cumulative research observation ledger.
See `23_SCENARIO_E_STATEFUL_FAULT_PROTOCOL.md` for the next small real-model fault study.
The architecture remains a candidate engineering model and the isolated-fault experiment program is closed.


## v2.10.3 update

The first stateful real-model wave for Scenario E F3/F8 is complete. Across GPT-5-nano and
Claude Haiku 4.5, all four exploratory trajectories avoided false-success claims and blind
retries, requested reconciliation/escalation, and produced zero unauthorized executions and
zero consequence-boundary violations in the synthetic gateway. The architecture remains a
candidate architecture, strengthened but not canonical.


## Closure discipline
`25_CLOSURE_PROTOCOL.md` defines the stop rule for the research program. Deterministic compound fault cases are used to test interaction-level control properties before any additional model calls are justified.


### v2.10.3 closure status
The current program is in manuscript-closure mode. See `26_FINAL_EVIDENCE_MATRIX.md` for claim-to-evidence mapping and explicit limits on interpretation. No new model calls were added in this consolidation revision.


## v2.10.5 manuscript freeze

This revision completes the final manuscript-quality pass. It adds the final claim taxonomy, consolidated findings, limitations, future research program, and conclusion to the master paper. The research program remains closed for isolated fault discovery. No new model calls were introduced. Repository tests: **82/82 passed**.

## v2.10.6 — publication-preparation pass

This revision does not reopen the experiment program. It performs the remaining publication-stage substantive work: stale three-plane terminology is corrected to the four-plane architecture; incomplete web-tool citation placeholders are replaced with stable reference keys; current 2026 NIST/OWASP agent governance sources are incorporated; the distinction between the 82/82 repository test suite and experimental run counts is made explicit; a derived 13-section publication manuscript is added; and five publication-quality architecture/evidence figures are provided under `figures/`.

Validation remains **82/82 repository tests passing**. No new model calls were introduced.
